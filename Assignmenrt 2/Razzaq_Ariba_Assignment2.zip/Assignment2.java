
import java.util.concurrent.Semaphore;

public class Assignment2 {

    // Entry point of the program
    public static void main(String[] args) throws Exception {
        // Initialize the materials
        Globals.isEnvelope = false;
        Globals.isFlyer = false;
        Globals.isStamp = false;

        // Initialize semaphores for the materials
        Globals.envelope = new Semaphore(0, true);
        Globals.flyer = new Semaphore(0, true);
        Globals.stamp = new Semaphore(0, true);

        // Initialize the semaphores for the agents and volunteers
        Globals.agentSem = new Semaphore(1, true);
        Globals.envelopeSem = new Semaphore(0, true);
        Globals.flyerSem = new Semaphore(0, true);
        Globals.stampSem = new Semaphore(0, true);

        // Initialize semaphore for mutex
        Globals.mutex = new Semaphore(1, true);

        Thread[] threads = {
            // Create the agents and the materials they produce
            new Agent("1"),
            new Agent("2"),
            new Agent("3"),
            // Create the pushers that signals volunteers when
            // a material is produced
            new Pusher(Globals.envelope),
            new Pusher(Globals.flyer),
            new Pusher(Globals.stamp),
            // Create the volunteers who makes the mails
            new Volunteer("[EnvelopeHolder 1]", Globals.envelopeSem),
            new Volunteer("[EnvelopeHolder 2]", Globals.envelopeSem),
            new Volunteer("[FlyerHolder 1]", Globals.flyerSem),
            new Volunteer("[FlyerHolder 2]", Globals.flyerSem),
            new Volunteer("[StampHolder 1]", Globals.stampSem),
            new Volunteer("[StampHolder 2]", Globals.stampSem)};

        // Start the threads
        for (Thread thread : threads) {
            thread.start();
        }

        // Wait for all threads to finish
        for (Thread thread : threads) {
            thread.join();
        }
    }
}
